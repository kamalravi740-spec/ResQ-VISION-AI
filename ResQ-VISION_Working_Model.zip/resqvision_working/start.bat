@echo off
cd /d "%~dp0"
echo Starting ResQ-VISION...
node server.js
pause
