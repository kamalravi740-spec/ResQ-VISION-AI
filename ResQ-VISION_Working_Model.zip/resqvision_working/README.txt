RESQ-VISION — WORKING MODEL
============================

This folder turns your current single-file prototype into a real local web application with a backend.

WHAT IS NOW WORKING
-------------------
1. Frontend: your existing ResQ-VISION design is kept.
2. Backend: Node.js server.
3. Database: SQLite (created automatically on first run).
4. Login: people/admin demo sessions are stored on the server.
5. Reports: reports are saved in SQLite instead of only browser storage.
6. Evidence: photo/video/voice files can be uploaded to the server.
7. AI triage: backend AI-triage endpoint gives category, urgency, title and reasoning.
8. Admin status: Received -> Under review -> In progress -> Resolved is saved on the backend.
9. Resource Hub: resources can be added, edited, deleted and status changed.
10. Resource matching: backend can match a need to available resources.
11. Volunteer registration: volunteer records are stored in SQLite.
12. SOS logging: SOS events and available GPS coordinates are recorded.
13. Offline queue: text-only reports can be queued in the browser and synchronized when the connection returns.
14. Early-warning demo: the backend has a risk endpoint and the home screen shows the result.
15. Command Center: command-center.html demonstrates risk -> resource match -> route decision -> incident status -> volunteers.

IMPORTANT HONESTY RULE
----------------------
This is a hackathon working model, not an authorized emergency-dispatch system.
The risk score is a demonstration rule. The current backend AI is a deterministic triage fallback, not a trained disaster-vision model.
For production, replace these pieces with authorized government data, verified routing, a trained/approved AI service, secure authentication and proper responder integrations.

REQUIREMENTS
------------
- Node.js 22 or newer.
- A laptop/PC for the easiest demo.
- Internet is useful for live weather/risk data, but the core report/database demo works locally.

START IT — VERY SIMPLE
----------------------
STEP 1
Install Node.js 22+ on the laptop.

STEP 2
Open this project folder in Terminal / Command Prompt.

STEP 3
Run:
    node server.js

STEP 4
Open:
    http://localhost:3000

STEP 5
Login as People & community for the citizen demo.
Login as Admin / coordinator for the responder demo.
For the hackathon demo, any non-empty name and password are accepted.

STEP 6
Click "Open Command Center" on the home screen after login to show the backend operations layer.

NO npm install is required for this version.
The backend uses Node's built-in HTTP server and SQLite support.

MAIN DEMO SCENARIO
------------------
Use one story, exactly as your presentation strategy recommends:

1. Flood occurs near a school in Goa.
2. Citizen opens Report an issue.
3. Citizen enters: "Water is entering houses near the school after heavy rain."
4. Add a photo from the phone camera/gallery.
5. Use current GPS or enter the location.
6. Use ResQ AI to suggest category and urgency.
7. Submit the report.
8. Show the reference number.
9. Switch to Admin / coordinator.
10. Open Admin workspace.
11. Show the same report coming from SQLite.
12. Change status: Received -> Under review -> In progress -> Resolved.
13. Open Command Center.
14. Show Early Warning -> Action.
15. Show Resource Auto-Match.
16. Show Hazard-Aware Route Check.
17. Register a volunteer.
18. Explain that SOS logs the event while the phone still performs the emergency call.

BACKEND ARCHITECTURE
--------------------
Phone/Laptop browser
        |
        v
ResQ-VISION HTML/CSS/JS
        |
        | HTTP / JSON / multipart upload
        v
Node.js backend (server.js)
        |
        +------ SQLite database (data/resqvision.db)
        |
        +------ Evidence files (uploads/)
        |
        +------ AI triage endpoint
        |
        +------ Risk/weather endpoint
        |
        +------ Resource matching
        |
        +------ Volunteer records
        |
        +------ SOS/event log
        |
        v
Admin / Command Center

FILES
-----
public/index.html          Your main ResQ-VISION interface.
public/backend-bridge.js   Connects the interface to the backend.
public/backend-bridge.css  Small styles for backend/risk status.
public/command-center.html Operations demonstration page.
server.js                  Backend + SQLite API.
package.json               Node project information.
HACKATHON_PLAN.txt         What to build next and how it maps to marks.
DEMO_SCRIPT.txt            Exact demo order for judges.
API_REFERENCE.txt          Backend endpoints.

DATA CREATED AUTOMATICALLY
---------------------------
data/resqvision.db          SQLite database.
uploads/                    Uploaded photo/video/voice evidence.

BACKUP
------
Before the competition, copy the whole project folder to a USB drive.
Also keep one ZIP copy on another device.

RESET DEMO DATA
---------------
Stop the server, delete:
    data/resqvision.db
Then start the server again.
The database and demo resources will be recreated.

SECURITY NOTE
-------------
The login is intentionally simple for a hackathon demonstration. It is NOT production authentication.
Do not use real passwords, citizen personal data, medical data, or sensitive government data in this demo.
