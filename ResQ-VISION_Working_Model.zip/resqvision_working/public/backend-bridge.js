/* ResQ-VISION backend bridge
   Connects the existing single-page prototype to the Express/SQLite server.
   The UI remains usable if the server is unavailable; text reports are queued locally and synced later.
*/
(() => {
  const API = '/api';
  const TOKEN_KEY = 'resqBackendToken';
  const USER_KEY = 'resqBackendUser';
  const QUEUE_KEY = 'resqOfflineQueueV1';
  const $ = (id) => document.getElementById(id);
  const toastSafe = (msg) => typeof toast === 'function' ? toast(msg) : console.log(msg);

  async function request(path, options = {}) {
    const headers = new Headers(options.headers || {});
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) headers.set('x-resq-token', token);
    if (!(options.body instanceof FormData) && options.body && !headers.has('Content-Type')) headers.set('Content-Type','application/json');
    const r = await fetch(API + path, {...options, headers});
    let data = null;
    try { data = await r.json(); } catch (_) { data = {}; }
    if (!r.ok) throw new Error(data.error || `Server error ${r.status}`);
    return data;
  }

  function setBackendBadge(ok, text) {
    let badge = $('resqBackendBadge');
    if (!badge) {
      badge = document.createElement('span'); badge.id='resqBackendBadge'; badge.className='resq-backend-badge';
      document.querySelector('.top-actions')?.prepend(badge);
    }
    badge.className='resq-backend-badge '+(ok?'online':'offline');
    badge.innerHTML=`<span class="resq-backend-dot"></span>${text}`;
  }

  async function health() {
    try { const h=await fetch(API+'/health').then(r=>r.json()); setBackendBadge(!!h.ok,'Backend online'); return true; }
    catch (_) { setBackendBadge(false,'Offline mode'); return false; }
  }

  function currentUser() { try{return JSON.parse(localStorage.getItem(USER_KEY)||'null')}catch(_){return null} }
  function saveSession(data) { localStorage.setItem(TOKEN_KEY,data.token); localStorage.setItem(USER_KEY,JSON.stringify(data.user)); }

  async function backendLogin() {
    const name=$('loginName')?.value.trim(), password=$('loginPassword')?.value || '', role=document.querySelector('input[name="loginType"]:checked')?.value || 'people';
    if(!name||!password){toastSafe('Enter a name and password to continue');return;}
    try {
      const data=await request('/auth/login',{method:'POST',body:JSON.stringify({name,password,role})});
      saveSession(data);
      demoUser=data.user;
      syncRole();
      toastSafe(role==='admin'?'Backend admin session started':'Backend people session started');
      go(role==='admin'?'admin':'home');
      await syncReports();
      await syncResourcesToLocal();
    } catch(e) { toastSafe('Backend login failed: '+e.message); }
  }

  async function syncReports() {
    if(!localStorage.getItem(TOKEN_KEY)) return;
    try {
      const rows=await request('/reports');
      reports=rows.map(r=>({
        id:r.id,category:r.category,title:r.title,description:r.description,location:r.location,
        urgency:r.urgency||'Not sure',contact:r.contact||'',anonymous:!!r.anonymous,status:r.status,
        date:new Date(r.created_at).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'}),
        photoName:r.evidence?.find(x=>x.kind==='photo')?.original_name||'',
        videoName:r.evidence?.find(x=>x.kind==='video')?.original_name||'',
        voiceName:r.evidence?.find(x=>x.kind==='voice')?.original_name||''
      }));
      save(); updateDashboard(); renderReports(); renderAffected?.();
      return rows;
    } catch(e) { if(e.message.includes('Authentication')) localStorage.removeItem(TOKEN_KEY); }
  }

  function buildFormData() {
    const fd=new FormData();
    fd.append('category',$('category').value); fd.append('title',$('title').value.trim());
    fd.append('description',$('description').value.trim()); fd.append('location',$('location').value.trim());
    fd.append('urgency',$('urgency').value); fd.append('contact',$('contact').value); fd.append('anonymous',$('anonymousReport').checked?'1':'0');
    const loc=$('location'); const m=(loc?.value||'').match(/Current GPS:\s*(-?\d+\.\d+),\s*(-?\d+\.\d+)/);
    if(m){fd.append('latitude',m[1]);fd.append('longitude',m[2]);}
    const photo=$('photo')?.files?.[0]; if(photo)fd.append('photo',photo,photo.name);
    try { if(reportVideoFile)fd.append('video',reportVideoFile,reportVideoFile.name); } catch(_) {}
    try { if(reportVoiceFile)fd.append('voice',reportVoiceFile,reportVoiceFile.name); } catch(_) {}
    return fd;
  }

  function queueOffline() {
    const item={category:$('category').value,title:$('title').value.trim(),description:$('description').value.trim(),location:$('location').value.trim(),urgency:$('urgency').value,contact:$('contact').value,anonymous:$('anonymousReport').checked,queuedAt:new Date().toISOString()};
    const q=JSON.parse(localStorage.getItem(QUEUE_KEY)||'[]'); q.push(item); localStorage.setItem(QUEUE_KEY,JSON.stringify(q));
    toastSafe('No backend connection. Report saved to the offline queue.');
  }

  async function submitBackendReport(ev) {
    ev.preventDefault(); ev.stopImmediatePropagation();
    const form=ev.currentTarget; if(!form.reportValidity()){setReportStep(3);return;}
    if(!localStorage.getItem(TOKEN_KEY)){toastSafe('Sign in first so the backend can save your report.');go('login');return;}
    const btn=$('submitBtn'); btn.disabled=true; const old=btn.innerHTML; btn.innerHTML='<span class="rv-spinner"></span>Saving to server…';
    try {
      const data=await request('/reports',{method:'POST',body:buildFormData()});
      $('#referenceNumber').textContent=data.id; $('#successModal').classList.add('open');
      await syncReports(); resetReportUI(); toastSafe('Report saved to the ResQ-VISION backend.');
    } catch(e) {
      if(/Failed to fetch|NetworkError|Load failed/i.test(e.message)) queueOffline(); else toastSafe('Could not save report: '+e.message);
    } finally { btn.disabled=false; btn.innerHTML=old; iconRefresh?.(); }
  }

  async function syncOfflineQueue() {
    const token=localStorage.getItem(TOKEN_KEY); if(!token)return;
    const q=JSON.parse(localStorage.getItem(QUEUE_KEY)||'[]'); if(!q.length)return;
    try { const out=await request('/offline-sync',{method:'POST',body:JSON.stringify({reports:q})});
      if(out.synced){localStorage.setItem(QUEUE_KEY,JSON.stringify(q.slice(out.synced)));await syncReports();toastSafe(`${out.synced} offline report(s) synchronized.`);}
    } catch(_){}
  }

  async function aiFillFromBackend(ev) {
    ev.preventDefault(); ev.stopImmediatePropagation();
    const prompt=$('aiReportPrompt')?.value.trim(); if(!prompt){toastSafe('Describe the issue first so ResQ AI can help.');return;}
    const btn=$('aiFillReportBtn');btn.disabled=true;$('aiReportStatus').textContent='ResQ AI is analyzing the report…';
    try {
      const r=await request('/ai/triage',{method:'POST',body:JSON.stringify({prompt})});
      $('category').value=r.category; document.querySelectorAll('.category-card').forEach(c=>c.classList.toggle('selected',c.dataset.value===r.category)); $('categoryCounter').textContent='1 selected';
      $('title').value=r.title; $('description').value=prompt.slice(0,1200); $('urgency').value=r.urgency; $('descriptionCount').textContent=$('description').value.length+' / 1200';
      $('aiReportStatus').textContent=`AI triage suggestion ready · ${Math.round((r.confidence||0)*100)}% rule confidence · human review required.`;
      $('aiSuggestion').hidden=false; $('aiSuggestion').innerHTML=`<strong>Suggested:</strong> ${safe(r.category)} · ${safe(r.urgency)} · “${safe(r.title)}”<br><span class="tiny muted">${safe(r.reasoning)}</span>`;
      updateReportReview();toastSafe('Backend AI triage filled the draft.');
    } catch(e) { toastSafe('AI service unavailable; using the local prototype logic.'); applyAiSuggestion(); }
    finally {btn.disabled=false;}
  }

  async function captureSOS() {
    const post=(lat,lon)=>request('/sos',{method:'POST',body:JSON.stringify({latitude:lat,longitude:lon,eventType:'SOS'})}).catch(()=>null);
    if(navigator.geolocation){navigator.geolocation.getCurrentPosition(p=>post(p.coords.latitude,p.coords.longitude),()=>post(null,null),{enableHighAccuracy:true,timeout:5000,maximumAge:10000});} else post(null,null);
  }

  async function syncResourcesToLocal(){
    try{const data=await request('/resources');localStorage.setItem('resqResourceHubV1',JSON.stringify(data));if(typeof renderResourceHub==='function'&&demoUser?.role==='admin')renderResourceHub();}catch(_){}
  }

  async function syncAdminStatus(ev){
    const sel=ev.target.closest('[data-status-id]'); if(!sel)return; ev.stopImmediatePropagation();
    try{await request('/reports/'+encodeURIComponent(sel.dataset.statusId)+'/status',{method:'PATCH',body:JSON.stringify({status:sel.value})});await syncReports();toastSafe('Status updated on the backend.');}
    catch(e){toastSafe('Backend status update failed: '+e.message);}
  }

  function injectDemoOpsCard(){
    const home=document.querySelector('#page-home'); if(!home||$('resqOpsCard'))return;
    const el=document.createElement('div');el.id='resqOpsCard';el.className='resq-ops-card';
    el.innerHTML=`<div class="resq-ops-head"><div><div class="eyebrow">Early warning → action</div><h2>Disaster readiness signal</h2><p id="resqRiskText">Checking the weather/risk service…</p></div><span id="resqRiskBadge" class="status progress">Checking</span></div><div class="resq-ops-grid"><div><strong>Official-data ready</strong><small>Designed to accept authorized warnings and weather feeds.</small></div><div><strong>Action layer</strong><small>Turn a risk signal into shelter, route and response actions.</small></div><div><strong>Backend</strong><small>Reports, status, resources and SOS are stored in SQLite.</small></div></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-outline" id="resqRefreshRisk"><i data-lucide="refresh-cw"></i>Refresh risk signal</button><button class="btn btn-primary" id="resqCommandCenter"><i data-lucide="layout-dashboard"></i>Open Command Center</button></div>`;
    const strip=home.querySelector('.alert-strip'); strip?.after(el); if(window.lucide)lucide.createIcons();
    $('resqRefreshRisk').onclick=loadRisk; $('resqCommandCenter').onclick=()=>location.href='/command-center.html';
  }
  async function loadRisk(){
    try{const p=await request('/risk?lat=15.4909&lon=73.8278');const r=p.risk;const badge=$('resqRiskBadge'),txt=$('resqRiskText');badge.textContent=r.level;badge.className='status '+(r.level==='HIGH'?'urgent':r.level==='MEDIUM'?'review':'resolved');txt.textContent=r.reason+(r.source?` Source: ${r.source}.`:'');}
    catch(e){$('resqRiskText').textContent='Risk service unavailable. Use official government alerts for real decisions.';$('resqRiskBadge').textContent='Unavailable';}
  }

  document.addEventListener('click',e=>{
    if(e.target.closest('#loginSubmit')){e.preventDefault();e.stopImmediatePropagation();backendLogin();}
    if(e.target.closest('#aiFillReportBtn')){aiFillFromBackend(e);}
    if(e.target.closest('#sosButton')||e.target.closest('#sosButtonPage'))captureSOS();
  },true);
  document.addEventListener('submit',e=>{if(e.target?.id==='reportForm')submitBackendReport(e);},true);
  document.addEventListener('change',e=>{if(e.target?.matches('[data-status-id]'))syncAdminStatus(e);},true);
  document.addEventListener('click',async e=>{
    const status=e.target.closest('[data-resource-status]');
    if(status){e.preventDefault();e.stopImmediatePropagation();try{const data=JSON.parse(localStorage.getItem('resqResourceHubV1')||'[]');const r=data.find(x=>x.id===status.dataset.resourceStatus);if(!r)return;const next={Available:'Busy',Busy:'Unavailable',Unavailable:'Available'};r.status=next[r.status]||'Available';await request('/resources/'+encodeURIComponent(r.id),{method:'PUT',body:JSON.stringify(r)});localStorage.setItem('resqResourceHubV1',JSON.stringify(await request('/resources')));renderResourceHub();toastSafe('Resource status saved to the backend.')}catch(err){toastSafe('Resource update failed: '+err.message)}}
    const del=e.target.closest('[data-resource-delete]');
    if(del){e.preventDefault();e.stopImmediatePropagation();try{const data=JSON.parse(localStorage.getItem('resqResourceHubV1')||'[]');const r=data.find(x=>x.id===del.dataset.resourceDelete);if(!r||!confirm(`Delete ${r.name} from the backend?`))return;await request('/resources/'+encodeURIComponent(r.id),{method:'DELETE'});await syncResourcesToLocal();toastSafe('Resource deleted from the backend.')}catch(err){toastSafe('Resource delete failed: '+err.message)}}
  },true);
  document.addEventListener('submit',async e=>{
    if(e.target?.id!=='resourceForm')return;e.preventDefault();e.stopImmediatePropagation();
    try{const f={name:$('resourceName').value.trim(),type:$('resourceType').value,location:$('resourceLocation').value.trim(),contact:$('resourceContact').value.trim(),status:$('resourceStatus').value,quantity:Number($('resourceQuantity').value)||1,notes:$('resourceNotes').value.trim()};const editId=$('resourceFormPanel').dataset.editId;const out=await request(editId?'/resources/'+encodeURIComponent(editId):'/resources',{method:editId?'PUT':'POST',body:JSON.stringify(f)});await syncResourcesToLocal();closeResourceForm();toastSafe(editId?'Resource updated on the backend.':'Resource added to the backend.')}catch(err){toastSafe('Resource save failed: '+err.message)}} ,true);
  window.addEventListener('online',syncOfflineQueue);

  (async()=>{
    const ok=await health(); injectDemoOpsCard(); await loadRisk();
    const saved=currentUser(); if(saved&&localStorage.getItem(TOKEN_KEY)){try{demoUser=saved;syncRole();go(saved.role==='admin'?'admin':'home');await syncReports();await syncResourcesToLocal();}catch(_) {}}
    if(ok) await syncOfflineQueue();
  })();
})();
