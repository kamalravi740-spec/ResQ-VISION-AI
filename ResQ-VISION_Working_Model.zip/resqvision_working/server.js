const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { URL } = require('node:url');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname, PUBLIC = path.join(ROOT,'public'), DATA = path.join(ROOT,'data'), UPLOADS = path.join(ROOT,'uploads');
fs.mkdirSync(DATA,{recursive:true}); fs.mkdirSync(UPLOADS,{recursive:true});
const db = new DatabaseSync(path.join(DATA,'resqvision.db'));
db.exec(`PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,role TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reports(id TEXT PRIMARY KEY,user_id INTEGER,category TEXT NOT NULL,title TEXT NOT NULL,description TEXT NOT NULL,location TEXT NOT NULL,latitude REAL,longitude REAL,urgency TEXT,ai_category TEXT,ai_title TEXT,ai_urgency TEXT,ai_reasoning TEXT,status TEXT NOT NULL DEFAULT 'Received',anonymous INTEGER NOT NULL DEFAULT 0,contact TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS evidence(id INTEGER PRIMARY KEY AUTOINCREMENT,report_id TEXT NOT NULL,kind TEXT NOT NULL,original_name TEXT NOT NULL,stored_name TEXT NOT NULL,mime_type TEXT,size_bytes INTEGER,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS resources(id TEXT PRIMARY KEY,name TEXT NOT NULL,type TEXT NOT NULL,location TEXT NOT NULL,contact TEXT,status TEXT,quantity INTEGER,notes TEXT,created_at TEXT,updated_at TEXT);
CREATE TABLE IF NOT EXISTS sos_events(id TEXT PRIMARY KEY,user_id INTEGER,event_type TEXT,latitude REAL,longitude REAL,created_at TEXT);
CREATE TABLE IF NOT EXISTS alerts(id TEXT PRIMARY KEY,title TEXT NOT NULL,message TEXT NOT NULL,severity TEXT,area TEXT,action TEXT,source TEXT,starts_at TEXT,ends_at TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS volunteers(id TEXT PRIMARY KEY,user_id INTEGER,name TEXT NOT NULL,skills TEXT,location TEXT,status TEXT,created_at TEXT,updated_at TEXT);
CREATE TABLE IF NOT EXISTS checkins(id TEXT PRIMARY KEY,user_id INTEGER,status TEXT NOT NULL,location TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,action TEXT,entity_type TEXT,entity_id TEXT,details TEXT,created_at TEXT);`);
const now=()=>new Date().toISOString();
const uid=(p='RV')=>`${p}-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
const sessions=new Map(); const MAX_MB=Number(process.env.MAX_UPLOAD_MB||25);

function seed(){
 if(!db.prepare('SELECT COUNT(*) n FROM resources').get().n){const rows=[
 ['RES-PWD-001','PWD Road Team 03','Response Team','Panaji','PWD Roads Division','Available',1,'Road defect inspection and repair crew.'],
 ['RES-EMS-001','Emergency Ambulance A1','Emergency','Panaji','112 / local dispatch','Available',1,'Emergency medical transport.'],
 ['RES-FIR-001','Fire & Rescue Unit 02','Response Team','Mapusa','Fire & Emergency Services','Busy',1,'Rescue and incident response unit.'],
 ['RES-EQP-001','JCB / Excavator 02','Equipment','Ponda','Operations desk','Available',1,'Heavy equipment for road obstruction and repair work.'],
 ['RES-FAC-001','District Hospital Support','Facility','North Goa','Hospital coordination desk','Available',1,'Facility resource for incident coordination.'],
 ['RES-EQP-002','Portable Generator 03','Equipment','Margao','Logistics desk','Unavailable',2,'Backup power equipment.']];
 const s=db.prepare('INSERT INTO resources VALUES (?,?,?,?,?,?,?,?,?,?)'); for(const r of rows)s.run(...r,now(),now());}
 if(!db.prepare('SELECT COUNT(*) n FROM alerts').get().n)db.prepare('INSERT INTO alerts VALUES (?,?,?,?,?,?,?,?,?,?)').run('ALERT-DEMO-001','Demo flood readiness alert','Heavy rainfall scenario for the hackathon demonstration. Verify official warnings before taking action.','HIGH','Goa · school-zone demo','Move toward a confirmed shelter and avoid blocked roads.','ResQ-VISION demo scenario',now(),null,now());
} seed();

function json(res,status,obj){const b=Buffer.from(JSON.stringify(obj));res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':b.length,'Cache-Control':'no-store'});res.end(b)}
function text(res,status,s,type='text/plain'){const b=Buffer.from(s);res.writeHead(status,{'Content-Type':type,'Content-Length':b.length});res.end(b)}
function auth(req){const t=req.headers['x-resq-token'];return t?sessions.get(t):null}
function audit(user,action,type,id,details=''){db.prepare('INSERT INTO audit_log(user_id,action,entity_type,entity_id,details,created_at) VALUES (?,?,?,?,?,?)').run(user?.id||null,action,type,id||null,details,now())}
function triage(text=''){
 const t=text.toLowerCase();let category='Other community issue',urgency='Not sure',title='Community incident report',reasoning='No strong hazard keyword was detected; human review is recommended.';
 const rules=[
  [['flood','flooding','water entering','waterlogging','overflow','heavy rain'],'Flooding or waterlogging','Urgent concern','Flood / water incident'],
  [['trapped','stranded','cannot get out','rescue','missing person'],'Public Safety','Urgent concern','Possible rescue / trapped-person incident'],
  [['fire','smoke','burning'],'Public Safety','Urgent concern','Fire / smoke incident'],
  [['ambulance','injury','bleeding','unconscious','medicine','medical'],'Medical or welfare assistance','Urgent concern','Medical assistance request'],
  [['pothole','road blocked','road damage','fallen tree','bridge','road sign'],'Road or infrastructure damage','Needs attention soon','Road / infrastructure issue'],
  [['electricity','wire','power line','transformer'],'Electricity concern','Urgent concern','Utility safety concern']];
 for(const [words,c,u,ttl] of rules){const hits=words.filter(w=>t.includes(w));if(hits.length){category=c;urgency=u;title=ttl;reasoning=`Keyword evidence matched: ${hits.join(', ')}. This is a triage suggestion, not a verified diagnosis.`;break}}
 return {category,urgency,title,reasoning,confidence:urgency==='Not sure'?0.45:0.82,mode:'rule-based AI fallback'};
}
function safeNum(v){const n=Number(v);return Number.isFinite(n)?n:null}
function reportView(r){return {...r,anonymous:!!r.anonymous,evidence:db.prepare('SELECT kind,original_name,mime_type,size_bytes,created_at FROM evidence WHERE report_id=?').all(r.id)}}

async function body(req){
 const chunks=[];let total=0;const limit=MAX_MB*1024*1024+12*1024*1024;
 for await(const c of req){total+=c.length;if(total>limit)throw new Error('Request too large');chunks.push(c)}
 const buf=Buffer.concat(chunks);const ct=req.headers['content-type']||'';
 if(!buf.length)return {fields:{},files:{}};
 if(ct.includes('application/json'))return {fields:JSON.parse(buf.toString('utf8')),files:{}};
 if(ct.includes('application/x-www-form-urlencoded'))return {fields:Object.fromEntries(new URLSearchParams(buf.toString('utf8'))),files:{}};
 if(ct.includes('multipart/form-data')){
  const m=ct.match(/boundary=(?:"([^"]+)"|([^;]+))/i);if(!m)throw new Error('Missing multipart boundary');
  const boundary=Buffer.from('--'+(m[1]||m[2]));const fields={},files={};let pos=0;
  while(true){const start=buf.indexOf(boundary,pos);if(start<0)break;const next=buf.indexOf(boundary,start+boundary.length);if(next<0)break;let part=buf.slice(start+boundary.length,next);pos=next;
    if(part.slice(0,2).toString()==='\r\n')part=part.slice(2);if(part.slice(-2).toString()==='\r\n')part=part.slice(0,-2);if(part.equals(Buffer.from('--')))break;
    const sep=part.indexOf(Buffer.from('\r\n\r\n'));if(sep<0)continue;const headers=part.slice(0,sep).toString('utf8');let data=part.slice(sep+4);
    const dm=headers.match(/name="([^"]+)"/i);if(!dm)continue;const name=dm[1];const fm=headers.match(/filename="([^"]*)"/i);const cm=headers.match(/Content-Type:\s*([^\r\n]+)/i);
    if(fm&&fm[1]){if(data.length>MAX_MB*1024*1024)throw new Error('Uploaded file exceeds the size limit');const original=fm[1];const stored=crypto.randomBytes(12).toString('hex')+'-'+path.basename(original).replace(/[^a-zA-Z0-9._-]/g,'_');fs.writeFileSync(path.join(UPLOADS,stored),data);(files[name]??=[]).push({originalname:original,filename:stored,mimetype:cm?.[1]||'application/octet-stream',size:data.length});}
    else fields[name]=data.toString('utf8');
  }
  return {fields,files};
 }
 return {fields:{},files:{}};
}

function serveStatic(req,res,u){
 let pathname=decodeURIComponent(u.pathname);if(pathname==='/'||pathname==='')pathname='/index.html';const file=path.normalize(path.join(PUBLIC,pathname));if(!file.startsWith(PUBLIC))return text(res,403,'Forbidden');
 fs.stat(file,(err,st)=>{if(err||!st.isFile())return text(res,404,'Not found');const ext=path.extname(file).toLowerCase();const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml'};res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':ext==='.html'?'no-store':'public,max-age=3600'});fs.createReadStream(file).pipe(res)});
}

async function handle(req,res){
 const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);const p=u.pathname;const method=req.method||'GET';
 try{
  if(method==='GET'&&p==='/api/health')return json(res,200,{ok:true,service:'ResQ-VISION backend',time:now(),database:'SQLite',node:process.version});
  if(method==='POST'&&p==='/api/auth/login'){
   const {fields}=await body(req),name=String(fields.name||'').trim(),password=String(fields.password||''),role=fields.role||'people';
   if(!name||!password||!['people','admin'].includes(role))return json(res,400,{error:'Valid name, password and role are required'});
   const id=Number(db.prepare('INSERT INTO users(name,role,created_at) VALUES (?,?,?)').run(name,role,now()).lastInsertRowid);const user={id,name,role};const token=crypto.randomBytes(24).toString('hex');sessions.set(token,user);audit(user,'LOGIN','user',String(id),`role=${role}`);return json(res,200,{token,user});
  }
  const user=auth(req);if(p.startsWith('/api/')&&!user&&!['/api/health','/api/auth/login'].includes(p))return json(res,401,{error:'Authentication required'});
  if(method==='POST'&&p==='/api/ai/triage'){const {fields}=await body(req);const q=String(fields.prompt||'').trim();if(!q)return json(res,400,{error:'Prompt is required'});return json(res,200,triage(q));}
  if(method==='GET'&&p==='/api/reports'){
   const rows=user.role==='admin'?db.prepare('SELECT * FROM reports ORDER BY created_at DESC').all():db.prepare('SELECT * FROM reports WHERE user_id=? ORDER BY created_at DESC').all(user.id);return json(res,200,rows.map(reportView));
  }
  if(method==='POST'&&p==='/api/reports'){
   const {fields,files}=await body(req);if(!fields.category||!fields.title||!fields.description||!fields.location)return json(res,400,{error:'category, title, description and location are required'});
   const id=uid('RV'),t=now(),ai=triage(`${fields.title}\n${fields.description}`);db.prepare('INSERT INTO reports VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id,user.id,fields.category,fields.title,fields.description,fields.location,safeNum(fields.latitude),safeNum(fields.longitude),fields.urgency||'Not sure',ai.category,ai.title,ai.urgency,ai.reasoning,'Received',fields.anonymous==='1'||fields.anonymous==='true'?1:0,fields.contact||'',t,t);
   for(const [kind,arr] of Object.entries(files))for(const f of arr)db.prepare('INSERT INTO evidence(report_id,kind,original_name,stored_name,mime_type,size_bytes,created_at) VALUES (?,?,?,?,?,?,?)').run(id,kind,f.originalname,f.filename,f.mimetype,f.size,t);
   audit(user,'CREATE','report',id,fields.category);return json(res,201,reportView(db.prepare('SELECT * FROM reports WHERE id=?').get(id)));
  }
  if(method==='PATCH'&&p.startsWith('/api/reports/')&&p.endsWith('/status')){
   if(user.role!=='admin')return json(res,403,{error:'Admin role required'});const id=p.split('/')[3],{fields}=await body(req),allowed=['Received','Under review','In progress','Resolved'];if(!allowed.includes(fields.status))return json(res,400,{error:'Invalid status'});if(!db.prepare('SELECT 1 FROM reports WHERE id=?').get(id))return json(res,404,{error:'Report not found'});db.prepare('UPDATE reports SET status=?,updated_at=? WHERE id=?').run(fields.status,now(),id);audit(user,'STATUS_CHANGE','report',id,fields.status);return json(res,200,reportView(db.prepare('SELECT * FROM reports WHERE id=?').get(id)));
  }
  if(method==='POST'&&p==='/api/sos'){const {fields}=await body(req),id=uid('SOS');db.prepare('INSERT INTO sos_events VALUES (?,?,?,?,?,?)').run(id,user.id,fields.eventType||'SOS',safeNum(fields.latitude),safeNum(fields.longitude),now());audit(user,'SOS','sos',id,'Location captured if available');return json(res,201,{id,status:'recorded',message:'SOS event recorded. Emergency calling remains on the user device.'});}
  if(method==='GET'&&p==='/api/resources')return json(res,200,db.prepare('SELECT * FROM resources ORDER BY name').all());
  if(method==='POST'&&p==='/api/resources/match'){
    const {fields}=await body(req),need=String(fields.need||'').toLowerCase(),type=String(fields.type||'').toLowerCase(),location=String(fields.location||'').toLowerCase();
    const rows=db.prepare("SELECT * FROM resources WHERE status='Available' ORDER BY CASE WHEN lower(type)=? THEN 0 ELSE 1 END, name").all(type);
    const ranked=rows.map(r=>{const hay=`${r.name} ${r.type} ${r.location} ${r.notes||''}`.toLowerCase();let score=0;if(type&&r.type.toLowerCase()===type)score+=5;if(need&&hay.includes(need))score+=4;if(location&&r.location.toLowerCase().includes(location))score+=3;return {...r,matchScore:score}}).sort((a,b)=>b.matchScore-a.matchScore);return json(res,200,{need,type,location,matches:ranked.slice(0,5)});
  }
  if(method==='GET'&&p==='/api/checkins')return json(res,200,db.prepare('SELECT id,status,location,created_at FROM checkins ORDER BY created_at DESC LIMIT 50').all());
  if(method==='POST'&&p==='/api/checkins'){const {fields}=await body(req);const allowed=['SAFE','NEED_HELP','NO_CONTACT'];if(!allowed.includes(fields.status))return json(res,400,{error:'Invalid check-in status'});const id=uid('CHK');db.prepare('INSERT INTO checkins VALUES (?,?,?,?,?)').run(id,user.id,fields.status,fields.location||'',now());audit(user,'CHECKIN','checkin',id,fields.status);return json(res,201,{id,status:fields.status});}
  if(method==='GET'&&p==='/api/volunteers')return json(res,200,db.prepare('SELECT id,name,skills,location,status,created_at,updated_at FROM volunteers ORDER BY updated_at DESC').all());
  if(method==='POST'&&p==='/api/volunteers'){
    const {fields}=await body(req),id=uid('VOL');db.prepare('INSERT INTO volunteers VALUES (?,?,?,?,?,?,?,?)').run(id,user.id,String(fields.name||user.name),String(fields.skills||''),String(fields.location||''),'Available',now(),now());audit(user,'REGISTER','volunteer',id,'');return json(res,201,db.prepare('SELECT id,name,skills,location,status,created_at,updated_at FROM volunteers WHERE id=?').get(id));
  }
  if(method==='POST'&&p==='/api/route'){
    const {fields}=await body(req);const hazards=Array.isArray(fields.hazards)?fields.hazards:[];const blocked=hazards.filter(h=>String(h.status||'').toLowerCase().includes('high')||String(h.severity||'').toLowerCase()==='high');return json(res,200,{mode:'hazard-aware prototype',origin:fields.origin||'',destination:fields.destination||'',blockedHazards:blocked,routeDecision:blocked.length?'Avoid reported high-risk points and use an alternate road.':'No high-risk hazard was supplied; normal routing may be used.',productionNote:'Connect a verified routing provider plus live road/hazard feeds for production.'});
  }
  if(method==='POST'&&p==='/api/resources'){if(user.role!=='admin')return json(res,403,{error:'Admin role required'});const {fields}=await body(req),id=fields.id||uid('RES');db.prepare('INSERT INTO resources VALUES (?,?,?,?,?,?,?,?,?,?)').run(id,fields.name,fields.type||'Response Team',fields.location,fields.contact||'',fields.status||'Available',Math.max(1,Number(fields.quantity)||1),fields.notes||'',now(),now());audit(user,'CREATE','resource',id,'');return json(res,201,db.prepare('SELECT * FROM resources WHERE id=?').get(id));}
  if(method==='PUT'&&p.startsWith('/api/resources/')){if(user.role!=='admin')return json(res,403,{error:'Admin role required'});const id=p.split('/')[3],r=db.prepare('SELECT * FROM resources WHERE id=?').get(id);if(!r)return json(res,404,{error:'Resource not found'});const {fields}=await body(req);db.prepare('UPDATE resources SET name=?,type=?,location=?,contact=?,status=?,quantity=?,notes=?,updated_at=? WHERE id=?').run(fields.name||r.name,fields.type||r.type,fields.location||r.location,fields.contact??r.contact,fields.status||r.status,Math.max(1,Number(fields.quantity||r.quantity)||1),fields.notes??r.notes,now(),id);audit(user,'UPDATE','resource',id,'');return json(res,200,db.prepare('SELECT * FROM resources WHERE id=?').get(id));}
  if(method==='DELETE'&&p.startsWith('/api/resources/')){if(user.role!=='admin')return json(res,403,{error:'Admin role required'});const id=p.split('/')[3];db.prepare('DELETE FROM resources WHERE id=?').run(id);audit(user,'DELETE','resource',id,'');return json(res,200,{ok:true});}
  if(method==='GET'&&p==='/api/alerts')return json(res,200,db.prepare('SELECT * FROM alerts ORDER BY created_at DESC').all());
  if(method==='POST'&&p==='/api/alerts'){if(user.role!=='admin')return json(res,403,{error:'Admin role required'});const {fields}=await body(req),id=uid('ALT');if(!fields.title||!fields.message||!fields.area)return json(res,400,{error:'title, message and area required'});db.prepare('INSERT INTO alerts VALUES (?,?,?,?,?,?,?,?,?,?)').run(id,fields.title,fields.message,fields.severity||'MEDIUM',fields.area,fields.action||'',fields.source||'ResQ-VISION',fields.startsAt||now(),fields.endsAt||null,now());audit(user,'CREATE','alert',id,'');return json(res,201,db.prepare('SELECT * FROM alerts WHERE id=?').get(id));}
  if(method==='POST'&&p==='/api/offline-sync'){const {fields}=await body(req);let items=Array.isArray(fields.reports)?fields.reports:[]; if(typeof fields.reports==='string'){try{items=JSON.parse(fields.reports||'[]')}catch(_){items=[]}};const results=[];for(const b of items){try{if(!b.category||!b.title||!b.description||!b.location)throw new Error('missing required fields');const id=uid('RV'),t=now(),ai=triage(`${b.title}\n${b.description}`);db.prepare('INSERT INTO reports VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id,user.id,b.category,b.title,b.description,b.location,safeNum(b.latitude),safeNum(b.longitude),b.urgency||'Not sure',ai.category,ai.title,ai.urgency,ai.reasoning,'Received',b.anonymous?1:0,b.contact||'',t,t);results.push({ok:true,id})}catch(e){results.push({ok:false,error:e.message})}}audit(user,'OFFLINE_SYNC','report',null,`items=${items.length}`);return json(res,200,{synced:results.filter(x=>x.ok).length,results});}
  if(method==='GET'&&p==='/api/risk'){
   const lat=Number(u.searchParams.get('lat')||15.4909),lon=Number(u.searchParams.get('lon')||73.8278);let out={level:'UNKNOWN',score:0,reason:'Live weather unavailable; use official warnings.',source:null};
   if(process.env.LIVE_WEATHER!=='false'){try{const url=`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&hourly=precipitation&forecast_days=2&timezone=auto`;const d=await fetch(url).then(r=>r.ok?r.json():Promise.reject());const rain=Math.max(...(d.hourly?.precipitation||[]).slice(0,24),0);const score=Math.min(100,Math.round(rain*5));out={level:score>=70?'HIGH':score>=35?'MEDIUM':'LOW',score,reason:`Next 24h maximum hourly precipitation in the weather feed: ${rain.toFixed(1)} mm. This is a demonstration risk rule, not an official flood forecast.`,source:'Open-Meteo'}}catch(_){}}
   return json(res,200,{location:{latitude:lat,longitude:lon},risk:out});
  }
  if(method==='GET'&&p==='/api/dashboard'){const a=db.prepare('SELECT * FROM reports').all();return json(res,200,{reports:a.length,pending:a.filter(x=>x.status!=='Resolved').length,resolved:a.filter(x=>x.status==='Resolved').length,resources:db.prepare('SELECT COUNT(*) n FROM resources').get().n,alerts:db.prepare('SELECT COUNT(*) n FROM alerts').get().n});}
  if(method==='GET')return serveStatic(req,res,u);
  return json(res,404,{error:'Route not found'});
 }catch(e){console.error(e);return json(res,500,{error:e.message||'Server error'});}
}
http.createServer(handle).listen(PORT,()=>console.log(`ResQ-VISION working model: http://localhost:${PORT}`));
